# MAD_WE_G01_B01_INFLUX

An academic group project to make a Mobile Application.
Influx is a mobile application used to manage ones Finance.

## Group Leader - IT21370182 - Suraweera S. A. U. K (kavi20011211)
## Group Member - IT21250460 - De Silva Y. S. I (Isini09)
## Group Member - IT21267840 - Piyasinghe W. A. K. P (KavindyaPiyasinghe)
## Group Member - IT21271564 - Weerapola T. D. (tharishan13)
